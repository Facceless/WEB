﻿var A;
var B;
var a;
var b;
var D, S, P;


function getDia()
{
    A = +document.getElementById('A').value;
    B = +document.getElementById('B').value;
    document.getElementById('D').value = Math.sqrt(A * A + B * B).toFixed(3);
    this.D = Math.sqrt(A * A + B * B).toFixed(3);
}

function getS()
{
    A = +document.getElementById('A').value;
    B = +document.getElementById('B').value;
    document.getElementById('S').value = A * B;
    this.S = A * B;
}

function getP()
{
    A = +document.getElementById('A').value;
    B = +document.getElementById('B').value;
    document.getElementById('P').value = A * 2 + B * 2;
    this.P = A * 2 + B * 2;
}

function changeA()
{
    A = +document.getElementById('A').value;
    a = +document.getElementById('A%').value;
    
    document.getElementById('A').value = ((a / 100) * A + A).toFixed(3);
    if ((+(a / 100) * A + A).toFixed(0) - (+(a / 100) * A + A).toFixed(3) == 0)
    {
        document.getElementById('A').value = (+(a / 100) * A + A).toFixed(0)
        this.A = (+(a / 100) * A + A).toFixed(0);
    }

}

function changeB() {
    B = +document.getElementById('B').value;
    b = +document.getElementById("B%").value;
    document.getElementById('B').value = ((b / 100) * B + B).toFixed(3);
    B = ((b / 100) * B + B).toFixed(3);
}

function DeleteB()
{
    document.getElementById('B').value = '';
    document.getElementById('A').value = '';
    document.getElementById('P').value = '';
    document.getElementById('B%').value = '';
    document.getElementById('A%').value = '';
    document.getElementById('S').value = '';
    document.getElementById('D').value = '';
}

function random()
{
    document.getElementById('B').value = Math.floor(Math.random() * (100 - 1 + 1)) + 1;

    document.getElementById('A').value = Math.floor(Math.random() * (100 - 1 + 1)) + 1;
}

function create()
{
    var index = 1;
    var tr11 = document.getElementById('tr11'); //берем первую строку
    var table = document.getElementById('table1');
    var tr31 = document.createElement('tr'); //создаем еще строку

    var td31 = document.createElement('td'); td31.innerHTML = index++;
    td31.appendChild(document.createTextNode(index++));
    tr31.appendChild(td31);

    var td32 = document.createElement('td'); 
    td32.appendChild(document.createTextNode(this.A));
    tr31.appendChild(td32);

    var td33 = document.createElement('td'); 
    td33.appendChild(document.createTextNode(this.B));
    tr31.appendChild(td33);

    var td34 = document.createElement('td'); 
    td34.appendChild(document.createTextNode(this.S));
    tr31.appendChild(td34);

    var td35 = document.createElement('td'); 
    td35.appendChild(document.createTextNode(this.D));
    tr31.appendChild(td35);

    var td36 = document.createElement('td'); 
    td36.appendChild(document.createTextNode(this.P));
     tr31.appendChild(td36);
    
    table.appendChild(tr31); //кладем в таблицу новосозданную строку (последней)

}

 

